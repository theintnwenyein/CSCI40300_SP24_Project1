# Project 1
List of Words within the dictionary:

- List of 'short' classified words
Cat, Ice, Sun, The, It, for, Car, Bus Pen

- List of Medium classified words
Apple, Time, There, Moon, Food, Winter, Summer, Small, People, Lemon

- List of Large classified words
Elephant, Watermelon, Strawberrry, Pineapple, Cheetah, Students, Professors, Computer, Science

Instructions:
    To run the program, simply compile the program using the 'make' command. Once the program has been compiled
    correctly, the program will automatically begin to run. To run again without having to re-compile the program,
    use the command 'make executable'. Finally, to remove any compiled files, use the command 'make clean'.